
HOW TO UPLOAD THIS PROJECT TO YOUR GDEVELOP CLOUD (step-by-step)
-----------------------------------------------------------------
1) Unzip the downloaded zip on your computer (or mobile if you can extract files).
2) Open https://editor.gdevelop.io and SIGN IN with your account. If you don't have one, create it using username 'mdnasaralam' and your email.
3) In the GDevelop editor, go to: File -> New project from a file -> Choose File -> select the project.json from this unzipped folder -> Open.
   - If you see validation warnings, ignore them for now; the global variables and layouts will still import.
4) After the project loads, test it using the Preview (▶) button.
5) To host it on GDevelop Cloud: File -> Save to GDevelop Cloud (or Publish to GDevelop Cloud). Follow prompts.
6) After publishing, click the Share/Cloud icon and copy the project link. This is the direct link you can open on mobile.
7) On mobile, open that cloud link in your browser. If it asks to open in the editor, it should load the project in mobile view (no need to use 'Open a project').

If desktop import is not possible for you, let me know and I will give step-by-step to import via desktop mode on mobile browser (switch to desktop site) or create a simple video guide.
